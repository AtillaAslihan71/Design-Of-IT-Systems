
class MVCPattern 
{
    public static void main(String[] args) 
    {
        Student model  = retriveStudentFromDatabase();
  
        StudentView view = new StudentView();
  
        StudentController controller = new StudentController(model, view);
  
        controller.updateView();
  
        controller.setStudentName("Mesut ASLI");
  
        controller.updateView();
    }
  
    private static Student retriveStudentFromDatabase()
    {
        Student student = new Student();
        student.setName("Atilla ASLIHAN");
        student.setRollNo("36492");
        return student;
    }
      
}
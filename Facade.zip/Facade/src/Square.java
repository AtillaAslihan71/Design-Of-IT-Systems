
public class Square implements Shape {

  
   public void draw() {
      System.out.println("draw() the SQUARE");
   }
}